package ch11;

import java.util.Iterator;
import java.util.TreeSet;

//TreeSet이용

/*실행결과
PersonDTO [name=홍일, age=1]
PersonDTO [name=김구, age=9]
PersonDTO [name=김십, age=10]
PersonDTO [name=홍백, age=100]
PersonDTO [name=이순신, age=123] 
 */

//PersonDTO에서  재정의된 compareTo()메서드를 이용하여
//나이 순으로 정렬하는    클래스이다
//사용자 정의 객체를  나이순으로 정렬
public class PersonDTO_ex {

	public static void main(String[] args) {
		//TreeSet 준비
		TreeSet<PersonDTO> ts = new TreeSet<PersonDTO>();
		
		//PersonDTO객체 저장
		//저장될 때  나이순으로 정렬됨
		ts.add( new  PersonDTO("홍백", 100));
		ts.add( new  PersonDTO("홍일", 1)  );
		ts.add( new  PersonDTO("김구", 9)  );
		ts.add( new  PersonDTO("김십", 10)  );
		ts.add( new  PersonDTO("이순신", 123)  );
		
		//왼쪽 마지막노드에서    오른쪽마지막노드까지    반복해서 가져온다=>오름차순
		//참고  - 이진 검색 트리는 부모보다 작은 값을 왼쪽에, 큰 값은 오른쪽에 저장
		Iterator<PersonDTO> iter = ts.iterator();
		while( iter.hasNext() ) {
			PersonDTO  person = iter.next();
			//System.out.println( person.getName() );
			//System.out.println( person);라고 쓰면  오버라이딩된 person.toString()을 호출
			System.out.println( person.toString());
		}
		
	}

}







