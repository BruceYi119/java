package ch11;

import java.util.TreeSet;

//TreeSet - 교재p
public class TreeSet01 {

	public static void main(String[] args) {
		TreeSet<Integer> ts = new TreeSet<Integer>();
		
		ts.add( new Integer(10) );
		ts.add( new Integer(33) );
		ts.add( new Integer(100) );
		ts.add( new Integer(99) );
		ts.add( new Integer(5) );
		
		Integer num = null;
		
		System.out.println("가장 낮은 점수="+ts.first()  ); //5
		System.out.println("가장 높은 점수="+ts.last()  );  //100
		
		num = ts.lower(new Integer(20));
		System.out.println("20보다 아래인 점수 ="+ num); //20
		
		num = ts.higher(new Integer(90));
		System.out.println("90보다 위인 점수="+num); //99
		
		num = ts.floor(new Integer(99));
		System.out.println("99와 동일하거나 바로 아래 점수="+num); //99
		
		num = ts.ceiling(new Integer(98));
		System.out.println("99와 동일하거나 바로 위 점수="+num); //99
		
		while( !ts.isEmpty() ) {
			num = ts.pollFirst();
			System.out.println(num+"\t남은 객체수:"+ts.size());
		}
		
	}

}


























